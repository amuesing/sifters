# dois_14(gpt)_pitch

Sieve-derived pitches added to dois_14(gpt), preserving its rhythms, velocities,
gates and first parity. Default preset: creative. Read MUSICAL_DESIGN.md for the
exact mappings and reasoning.

## Run

From this directory:

```bash
../../../../.venv/bin/python -B composition.py
../../../../.venv/bin/python -B composition.py --all
../../../../.venv/bin/python -B composition.py --preset shared-weather
../../../../.venv/bin/python -B composition.py --all --dry-run
../../../../.venv/bin/python -B composition.py --all --diagnostics
../../../../.venv/bin/python -B composition.py --all --verify-only
../../../../.venv/bin/python -B -m unittest discover -s tests -v
```

Existing interpreter: /Users/amuesing/Documents/Development/.venv/bin/python.
Python 3.14 and requirements.txt dependencies are the tested environment.
--output-dir supplies a different root for the preset subfolders.

## Load into Ableton

Browse the ordinary `mid/creative/` folder. Start with
`dois_14(gpt)_pitch_creative_arrangement.mid` and use one pitched instrument per
voice. The four `_prime.mid` files are individual parts. `_ensemble.mid` contains
all voices on separate MIDI channels 1–4 for multitimbral routing.

**Do not use these as Drum Rack clips:** pitch now controls musical notes.
No sounds or program changes are embedded. Separate tracks avoid relying on a
single instrument's handling of overlapping same-pitch notes across channels.

There are six ordinary MIDI files plus render.json per preset, with no symlinks,
lock files, generation directories or duplicate browser copy. All 24 comparison
files are supplied. The 'reference' folder preserves the reference rhythm and
velocity policy, but adds pitches; it is not the original unpitched MIDI.

## Pitch configuration

Edit PITCH_CONFIG in config.py: each voice requires a MIDI root, motion and unique
1-based channel. Defaults: A ascending/root48/channel1; B descending/root48/channel2;
C pitch canon/root48/channel3; D slow ascending/root36/channel4. All use the source
sieve's selected integers as semitone offsets. Motion runs through rests as well as
attacks. Out-of-range pitches, duplicate channels and nonclosing fields are rejected.

A/B/C use 40-step pitch fields. D takes its entire existing span (80 creative steps)
to traverse the collection. No pitch rule extends the statement. The default
creative version has 255 notes over 40 quarter notes: 20 seconds at 120 BPM.
The existing 40/16 metadata displays four bars, equivalent to ten bars of 4/4.

## Implementation and verification

rhythm_engine.py is the previous pure rhythm/velocity planner, retained intact.
engine.py adds deterministic pitch fields and combined-pattern validation. Keeping
this boundary makes pitch changes independent of the established accent contract.
config.py contains musical inputs; midi_io.py handles exact event readback and
ordinary file exports; composition.py provides the CLI.

18 tests cover all parent onset/duration/velocity streams, independent pitch
arithmetic for every preset, all 24 MIDI files, pitch/channel corruption, pitch range,
canon phase, full-span closure, combined nonrepetition, manifests and ordinary exports.
The parent fixture was read directly from raw MIDI bytes. VALIDATION.json records
the last completed checks; rerun tests after edits.

Outputs are fully staged and verified before individual file replacement. Other
filenames are preserved; files under generated names are replaced. An interrupted
multi-file update may leave a mixed set: rerender and verify. Source or dependency
changes also require rerendering for current-runtime manifest verification.
The manifest is a consistency record, not an authenticity signature.

Previous projects remain untouched. Form and the Max/plugin work remain parked.
